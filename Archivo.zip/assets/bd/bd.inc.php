<?php

// $bdServidor = "127.0.0.1:3306";
// $bdUsuario = "root";
// $bdPassword = "root";
// $bdNombre = "copahue_formulario";

$bdServidor = "201.159.170.169";
$bdUsuario = "francisc_formulario";
$bdPassword = '.5eF+5elQ${I';
$bdNombre = "francisc_formulario";

$con = mysqli_connect($bdServidor, $bdUsuario, $bdPassword, $bdNombre);

?>